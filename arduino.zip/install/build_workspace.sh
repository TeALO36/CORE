#!/bin/bash
# ============================================================
# SpotBot -- Build ROS 2 workspace
# ============================================================
set -e

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
info()    { echo -e "${GREEN}[INFO]${NC} $1"; }
error()   { echo -e "${RED}[ERR]${NC} $1"; exit 1; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(dirname "$SCRIPT_DIR")"
WS_DIR="$REPO_DIR/ros2_ws"

source /opt/ros/jazzy/setup.bash

info "=== Build du workspace SpotBot ==="
info "Workspace: $WS_DIR"

cd "$WS_DIR"

# Installer les dependances via rosdep
info "Resolution des dependances rosdep..."
rosdep install --from-paths src --ignore-src -r -y --rosdistro jazzy

# Build
info "Build colcon (peut prendre 5-10 min sur Pi 5)..."
colcon build \
    --symlink-install \
    --cmake-args -DCMAKE_BUILD_TYPE=Release \
    --parallel-workers 2

info "=== Build termine ! ==="

# Source auto si pas deja fait
if ! grep -q "spotbot-ros2/ros2_ws/install/setup.bash" ~/.bashrc; then
    echo "source $WS_DIR/install/setup.bash" >> ~/.bashrc
fi

source "$WS_DIR/install/setup.bash"
info "Workspace source. Lancez: ros2 launch spotbot_bringup spotbot.launch.py"
