#!/bin/bash
# ============================================================
# SpotBot -- Install ROS 2 Jazzy on Raspberry Pi 5
# OS cible : Ubuntu 24.04 LTS (Noble) ARM64
# ============================================================
set -e

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
info()    { echo -e "${GREEN}[INFO]${NC} $1"; }
warning() { echo -e "${YELLOW}[WARN]${NC} $1"; }
error()   { echo -e "${RED}[ERR]${NC} $1"; exit 1; }

info "=== SpotBot ROS 2 Jazzy Installer ==="
. /etc/os-release
info "OS: $ID $VERSION_CODENAME ($(uname -m))"

# Verifier Ubuntu Noble (Pi 5 recommande)
if [[ "$VERSION_CODENAME" != "noble" ]]; then
    warning "Ce script est optimise pour Ubuntu 24.04 (Noble). OS detecte: $VERSION_CODENAME"
    warning "Continuer quand meme ? (Ctrl+C pour annuler)"
    sleep 3
fi

# ---- Prerequis ----
info "Installation des prerequis..."
sudo apt-get update -q
sudo apt-get install -y curl gnupg2 lsb-release software-properties-common apt-transport-https

# ---- Repo ROS 2 ----
if ! [ -f /usr/share/keyrings/ros-archive-keyring.gpg ]; then
    info "Ajout de la cle GPG ROS 2..."
    sudo curl -sSL https://raw.githubusercontent.com/ros/rosdistro/master/ros.key \
         -o /usr/share/keyrings/ros-archive-keyring.gpg
fi

if ! [ -f /etc/apt/sources.list.d/ros2.list ]; then
    info "Ajout du depot ROS 2 Jazzy..."
    echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/ros-archive-keyring.gpg] \
http://packages.ros.org/ros2/ubuntu noble main" | \
    sudo tee /etc/apt/sources.list.d/ros2.list > /dev/null
    sudo apt-get update -q
fi

# ---- Installation ROS 2 ----
if ros2 --version 2>/dev/null | grep -q jazzy; then
    info "ROS 2 Jazzy deja installe."
else
    info "Installation de ROS 2 Jazzy Desktop (peut prendre 10-20 min)..."
    sudo DEBIAN_FRONTEND=noninteractive apt-get install -y ros-jazzy-desktop
fi

# ---- Outils build ----
info "Installation des outils de build ROS..."
sudo apt-get install -y \
    python3-rosdep \
    python3-colcon-common-extensions \
    python3-vcstool \
    python3-pip \
    python3-argcomplete \
    build-essential

# ---- rosdep init ----
sudo rosdep init 2>/dev/null || true
rosdep update

# ---- Outils Arduino / Serial ----
info "Installation avrdude (flash Arduino)..."
sudo apt-get install -y avrdude

# ---- Ajouter utilisateur au groupe dialout (acces USB/Serial) ----
sudo usermod -aG dialout "$USER"
info "Utilisateur $USER ajoute au groupe dialout (redemarrage necessaire)"

# ---- Source automatique ----
if ! grep -q "source /opt/ros/jazzy/setup.bash" ~/.bashrc; then
    echo "" >> ~/.bashrc
    echo "# ROS 2 Jazzy" >> ~/.bashrc
    echo "source /opt/ros/jazzy/setup.bash" >> ~/.bashrc
    echo "source ~/spotbot-ros2/ros2_ws/install/setup.bash 2>/dev/null || true" >> ~/.bashrc
    info "ROS 2 ajoute au .bashrc"
fi

info "=== Installation ROS 2 Jazzy terminee ! ==="
info "Prochain: bash install/install_deps.sh"
