#!/bin/bash
# ============================================================
# SpotBot — Install arduino-cli + Compile + Flash firmware
# A executer UNE SEULE FOIS apres avoir branche l'Arduino Mega
# ============================================================
set -e

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; CYAN='\033[0;36m'; NC='\033[0m'
info()    { echo -e "${GREEN}[INFO]${NC} $1"; }
warning() { echo -e "${YELLOW}[WARN]${NC} $1"; }
error()   { echo -e "${RED}[ERR]${NC} $1"; exit 1; }
step()    { echo -e "\n${CYAN}════════════════════════════════${NC}"; echo -e "${CYAN} $1${NC}"; echo -e "${CYAN}════════════════════════════════${NC}"; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(dirname "$SCRIPT_DIR")"
SKETCH_DIR="$REPO_DIR/arduino/spotbot_controller"

step "1/4 Installation arduino-cli"
if ! command -v arduino-cli &>/dev/null; then
    info "Telechargement arduino-cli..."
    curl -fsSL https://raw.githubusercontent.com/arduino/arduino-cli/master/install.sh | sh
    sudo mv bin/arduino-cli /usr/local/bin/arduino-cli
    info "arduino-cli installe."
else
    info "arduino-cli deja installe: $(arduino-cli version)"
fi

step "2/4 Configuration arduino-cli"
arduino-cli config init --overwrite 2>/dev/null || true
arduino-cli core update-index

step "3/4 Installation du core Arduino AVR (Mega 2560)"
arduino-cli core install arduino:avr
info "Core Arduino AVR installe."

step "3.5/4 Installation des librairies Arduino"
info "SparkFun BNO08x (IMU BNO085 principal)..."
arduino-cli lib install "SparkFun BNO08x"
info "Librairies installees!"

step "4/4 Detection de l'Arduino Mega"
info "Recherche de l'Arduino en USB..."

ARDUINO_PORT=""
for dev in /dev/ttyUSB* /dev/ttyACM*; do
    if [ -e "$dev" ]; then
        ARDUINO_PORT="$dev"
        info "Arduino detecte sur: $ARDUINO_PORT"
        break
    fi
done

if [ -z "$ARDUINO_PORT" ]; then
    warning "Arduino non detecte automatiquement."
    read -rp "Entrez le port manuellement (ex: /dev/ttyUSB0): " ARDUINO_PORT
    [ -z "$ARDUINO_PORT" ] && error "Aucun port specifie."
fi

step "Compilation du firmware SpotBot"
info "Compilation de $SKETCH_DIR/spotbot_controller.ino..."
arduino-cli compile \
    --fqbn arduino:avr:mega \
    --build-path /tmp/spotbot_build \
    "$SKETCH_DIR"

info "Compilation reussie!"

step "Flash sur l'Arduino Mega ($ARDUINO_PORT)"
arduino-cli upload \
    --fqbn arduino:avr:mega \
    --port "$ARDUINO_PORT" \
    --input-dir /tmp/spotbot_build

info "=== Flash Arduino reussi! ==="
info "L'Arduino va redemarrer (2s)..."
sleep 2

# Test de communication
info "Test de communication Serial..."
timeout 3 cat "$ARDUINO_PORT" 2>/dev/null | head -2 || true

echo ""
info "=============================================="
info " Arduino Mega configure et pret!"
info " Port: $ARDUINO_PORT"
info " Pour relancer: bash install/install_arduino.sh"
info "=============================================="
