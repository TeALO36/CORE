#!/bin/bash
# ============================================================
# SpotBot -- Install ROS 2 dependencies
# Packages: rtabmap, nav2, camera drivers, IMU, serial
# ============================================================
set -e

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
info()    { echo -e "${GREEN}[INFO]${NC} $1"; }
warning() { echo -e "${YELLOW}[WARN]${NC} $1"; }

source /opt/ros/jazzy/setup.bash

info "=== Installation des dependances SpotBot ==="

# ---- Packages ROS 2 SLAM ----
info "Installation rtabmap + ORB-SLAM3 deps..."
sudo apt-get install -y \
    ros-jazzy-rtabmap-ros \
    ros-jazzy-rtabmap \
    ros-jazzy-slam-toolbox \
    ros-jazzy-robot-localization \
    ros-jazzy-imu-tools \
    ros-jazzy-imu-filter-madgwick

# ---- Navigation 2 ----
info "Installation Nav2..."
sudo apt-get install -y \
    ros-jazzy-nav2-bringup \
    ros-jazzy-nav2-map-server \
    ros-jazzy-nav2-amcl \
    ros-jazzy-navigation2

# ---- Drivers camera ----
info "Installation drivers camera USB..."
sudo apt-get install -y \
    ros-jazzy-usb-cam \
    ros-jazzy-camera-calibration \
    ros-jazzy-image-pipeline \
    ros-jazzy-stereo-image-proc \
    ros-jazzy-image-transport \
    ros-jazzy-compressed-image-transport \
    v4l-utils

# ---- Communication Serial Python ----
info "Installation pyserial + libs Python..."
pip3 install pyserial numpy transforms3d 2>/dev/null || \
sudo pip3 install pyserial numpy transforms3d

# ---- Streaming camera ----
info "Installation GStreamer + FFmpeg + v4l2..."
sudo apt-get install -y \
    gstreamer1.0-tools \
    gstreamer1.0-plugins-base \
    gstreamer1.0-plugins-good \
    gstreamer1.0-plugins-bad \
    gstreamer1.0-plugins-ugly \
    gstreamer1.0-libav \
    v4l-utils \
    ffmpeg

# ---- WiFi tools (pour watchdog Alfa) ----
info "Installation des outils WiFi..."
sudo apt-get install -y \
    wireless-tools \
    network-manager \
    iw \
    wpasupplicant

# ---- Visualisation ----
sudo apt-get install -y \
    ros-jazzy-rviz2 \
    ros-jazzy-rqt \
    ros-jazzy-rqt-graph \
    ros-jazzy-rqt-image-view

# ---- Autres utilitaires ----
sudo apt-get install -y \
    ros-jazzy-xacro \
    ros-jazzy-joint-state-publisher \
    ros-jazzy-joint-state-publisher-gui \
    ros-jazzy-robot-state-publisher \
    ros-jazzy-tf2-tools \
    ros-jazzy-tf2-ros

info "=== Toutes les dependances sont installees ! ==="
info "Prochain: bash install/build_workspace.sh"
