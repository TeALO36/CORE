#!/bin/bash
# ============================================================
# SpotBot — Installation drivers WiFi Alfa USB
# Compatible: RTL8812AU (AWUS036ACH/AC), RT3070 (AWUS036NH/H)
# ============================================================
set -e

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; CYAN='\033[0;36m'; NC='\033[0m'
info()    { echo -e "${GREEN}[INFO]${NC} $1"; }
warning() { echo -e "${YELLOW}[WARN]${NC} $1"; }
error()   { echo -e "${RED}[ERR]${NC} $1"; exit 1; }
step()    { echo -e "\n${CYAN}▶ $1${NC}"; }

step "Détection du module WiFi Alfa..."

# Détecter le chipset via lsusb
LSUSB_OUT=$(lsusb 2>/dev/null)
CHIPSET=""

if echo "$LSUSB_OUT" | grep -qiE '0bda:8812|0bda:881a|0bda:b812'; then
    CHIPSET="rtl8812au"
    info "Chipset détecté: Realtek RTL8812AU (AWUS036ACH/AC)"
elif echo "$LSUSB_OUT" | grep -qiE '148f:3070|148f:5370|148f:7601'; then
    CHIPSET="mt7601u"
    info "Chipset détecté: Ralink RT3070/MT7601 (AWUS036NH/H)"
else
    warning "Module Alfa non détecté. Vérifiez la connexion USB."
    warning "Si votre module n'est pas encore branché, rebranchez-le et relancez ce script."
    read -rp "Continuer quand même? (o/N): " ans
    [[ "$ans" != "o" && "$ans" != "O" ]] && exit 0
fi

step "Installation des prérequis..."
sudo apt-get install -y \
    dkms \
    git \
    build-essential \
    linux-headers-$(uname -r) \
    network-manager \
    wireless-tools \
    wpasupplicant

if [[ "$CHIPSET" == "rtl8812au" ]]; then
    step "Installation driver RTL8812AU..."
    if ! ls /lib/modules/$(uname -r)/kernel/drivers/net/wireless/ | grep -q rtl8812au 2>/dev/null; then
        TMP_DIR=$(mktemp -d)
        git clone --depth=1 https://github.com/aircrack-ng/rtl8812au.git "$TMP_DIR"
        cd "$TMP_DIR"
        sudo make dkms_install
        cd /
        rm -rf "$TMP_DIR"
        info "Driver RTL8812AU installé via DKMS"
    else
        info "Driver RTL8812AU déjà installé"
    fi
elif [[ "$CHIPSET" == "mt7601u" ]]; then
    info "Driver MT7601U intégré au kernel Linux — pas d'installation nécessaire"
fi

step "Configuration NetworkManager pour le dual-WiFi..."

# Désactiver NetworkManager.wait-online qui bloque le boot
sudo systemctl disable NetworkManager-wait-online.service 2>/dev/null || true

# Configurer le scanning agressif pour le roaming (sur wlan0)
CONF_FILE="/etc/NetworkManager/conf.d/spotbot-wifi.conf"
sudo tee "$CONF_FILE" > /dev/null << 'NMCONF'
# SpotBot WiFi Watchdog Configuration
[connection]
wifi.powersave = 2

[device]
wifi.scan-rand-mac-address = no

[main]
# Priorité: wlan0 = principale, wlan1 (Alfa) = backup
plugins = ifupdown,keyfile
NMCONF

info "Configuration NetworkManager: $CONF_FILE"

# Recharger NetworkManager
sudo systemctl reload NetworkManager 2>/dev/null || sudo systemctl restart NetworkManager

step "Vérification des interfaces..."
sleep 2

echo ""
info "Interfaces WiFi détectées:"
for iface in $(ls /sys/class/net/); do
    if [ -d "/sys/class/net/$iface/wireless" ]; then
        IP=$(ip -4 addr show "$iface" 2>/dev/null | grep -oP '(?<=inet )\d+\.\d+\.\d+\.\d+' || echo "sans IP")
        DBM=$(iwconfig "$iface" 2>/dev/null | grep -oP '(?<=Signal level=)-?\d+' || echo "?")
        info "  $iface: $IP (signal: ${DBM} dBm)"
    fi
done

echo ""
info "=== Installation WiFi Alfa terminée ! ==="
info ""
info "Le WiFi watchdog démarrera automatiquement avec le robot."
info "Si wlan0 signal faible (<-70 dBm) → bascule automatique vers Alfa"
info ""
info "Topics ROS 2:"
info "  /wifi/status       — état du routing actuel"
info "  /wifi/alfa_active  — True si Alfa est utilisé"
