<div align="center">

```
 ██████╗██████╗  ██████╗ ████████╗██████╗  ██████╗ ████████╗
██╔════╝██╔══██╗██╔═══██╗╚══██╔══╝██╔══██╗██╔═══██╗╚══██╔══╝
╚█████╗ ██████╔╝██║   ██║   ██║   ██████╔╝██║   ██║   ██║   
 ╚═══██╗██╔═══╝ ██║   ██║   ██║   ██╔══██╗██║   ██║   ██║   
██████╔╝██║     ╚██████╔╝   ██║   ██████╔╝╚██████╔╝   ██║   
╚═════╝ ╚═╝      ╚═════╝    ╚═╝   ╚═════╝  ╚═════╝    ╚═╝   
```

**Robot quadrupède autonome · V-SLAM · 12 servos · ROS 2 Jazzy**

[![ROS 2 Jazzy](https://img.shields.io/badge/ROS_2-Jazzy-blue?logo=ros)](https://docs.ros.org/en/jazzy/)
[![Raspberry Pi 5](https://img.shields.io/badge/Raspberry_Pi-5-red?logo=raspberry-pi)](https://www.raspberrypi.com/products/raspberry-pi-5/)
[![Arduino Mega](https://img.shields.io/badge/Arduino-Mega_2560-teal?logo=arduino)](https://www.arduino.cc/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

</div>

---

## 📋 Table des matières

1. [Vue d'ensemble](#vue-densemble)
2. [Ce que fait SpotBot](#ce-que-fait-spotbot)
3. [Matériel requis](#matériel-requis)
4. [Branchements hardware](#branchements-hardware)
5. [Installation complète](#installation-complète)
6. [Premier lancement](#premier-lancement)
7. [Commandes utiles](#commandes-utiles)
8. [Architecture du système](#architecture-du-système)
9. [Modes de fonctionnement](#modes-de-fonctionnement)
10. [Calibration des servos](#calibration-des-servos)
11. [Dépannage](#dépannage)
12. [Répertoire des fichiers](#répertoire-des-fichiers)

---

## Vue d'ensemble

SpotBot est un **robot quadrupède** de type SpotMicro entièrement autonome, capable de :

- Se lever, marcher, s'asseoir de manière autonome
- **Cartographier son environnement** en temps réel (V-SLAM)
- Naviguer vers des objectifs sur la carte générée
- Être contrôlé à distance via ROS 2

Le cerveau est un **Raspberry Pi 5** qui fait tourner ROS 2 Jazzy.  
Les 12 servos sont pilotés par un **Arduino Mega** via USB Serial.  
La vision est assurée par **1 ou 2 caméras USB génériques**.

---

## Ce que fait SpotBot

```
┌─────────────────────────────────────────────────────────────────┐
│                        Au lancement                             │
│                                                                 │
│  1. L'Arduino est détecté automatiquement sur USB               │
│  2. Le bridge ROS↔Arduino démarre                               │
│  3. Le robot SE LÈVE en position debout (12 servos à 90°)       │
│  4. La(les) caméra(s) USB démarre(nt)                           │
│  5. Le SLAM commence à cartographier l'environnement            │
│  6. Le robot est prêt à recevoir des commandes de mouvement     │
└─────────────────────────────────────────────────────────────────┘
```

**Flux de données :**
```
Caméra USB ──→ /camera/image_raw ──→ rtabmap ──→ Carte 2D/3D
                                          ↓
MPU6050 ─→ Arduino ─USB Serial→ Bridge ROS ─→ /imu/data ──→ rtabmap

Pi 5 ──→ /cmd_vel (Twist) ──→ Motion Node ──→ IK 12-DOF
                                                    ↓
                             /cmd_joint_angles ──→ Bridge ──→ Arduino
                                                               ↓
                                                    12x Servo MG996R
```

---

## Matériel requis

| # | Composant | Qté | Indispensable | Notes |
|---|-----------|-----|:---:|-------|
| 1 | **Raspberry Pi 5** (8 Go RAM) | 1 | ✅ | 16 Go si possible |
| 2 | Carte SD (64 Go, classe A2) | 1 | ✅ | Samsung Pro Endurance recommandée |
| 3 | **Arduino Mega 2560** | 1 | ✅ | Clone compatible OK |
| 4 | **Servo MG996R** | 12 | ✅ | Alimentés OBLIGATOIREMENT en externe |
| 5 | **MPU6050** (module GY-521) | 1 | ✅ | IMU gyroscope + accéléromètre |
| 6 | **Caméra USB générique** | 1 ou 2 | ✅ | 1 = mono SLAM, 2 = stéréo SLAM |
| 7 | **Alimentation externe 6V/10A** | 1 | ✅ | Pour les servos UNIQUEMENT |
| 8 | Alimentation Pi USB-C 5V/5A | 1 | ✅ | Officielle Raspberry Pi 5 |
| 9 | Câble USB-A → USB-B | 1 | ✅ | Pi 5 → Arduino Mega |
| 10 | Fils Dupont femelle-femelle | ~20 | ✅ | Pour MPU6050 et signaux servo |
| 11 | Condensateurs 1000µF 10V | 2 | ⚠️ | Fortement recommandé sur alim servos |
| 12 | Connecteur XT60 ou bornier | 1 | ⚠️ | Pour relier alim externe aux servos |

> **⚠️ CRITIQUE :** Ne jamais alimenter les servos via le 5V de l'Arduino ou du Pi. Un servo en charge peut consommer 2,5A — soit 30A pour 12 servos. Une alimentation externe dédiée est **obligatoire**.

---

## Branchements hardware

### 1. Vue d'ensemble des connexions

```
╔══════════════════╗    USB    ╔═══════════════════════╗
║  RASPBERRY PI 5  ║══════════║    ARDUINO MEGA 2560   ║
║                  ║          ║                        ║
║  USB-C ◄─5V/5A  ║          ║  D2  → Servo FR Abad   ║
║  USB-A ─→ Mega  ║          ║  D3  → Servo FR Upper  ║
║  USB-A ─→ CamG  ║          ║  D4  → Servo FR Lower  ║
║  USB-A ─→ CamD  ║          ║  D5  → Servo FL Abad   ║
║  (stéréo optio) ║          ║  D6  → Servo FL Upper  ║
╚══════════════════╝          ║  D7  → Servo FL Lower  ║
                              ║  D8  → Servo BR Abad   ║
                              ║  D9  → Servo BR Upper  ║
╔══════════════════╗  I2C     ║  D10 → Servo BR Lower  ║
║    MPU6050       ║══════════║  D11 → Servo BL Abad   ║
║  (GY-521)        ║ SDA=20   ║  D12 → Servo BL Upper  ║
║                  ║ SCL=21   ║  D13 → Servo BL Lower  ║
╚══════════════════╝          ║                        ║
                              ║  GND ◄──┐              ║
╔══════════════════╗          ╚═════════╪══════════════╝
║ ALIM EXTERNE     ║                   │
║ 6V / 10A         ║          ┌────────┘
║                  ║          │ GND COMMUN
║  (+) ────────────╬──────────╬──→ VCC rouge servos
║  (─) ────────────╬──────────╬──→ GND marron servos
╚══════════════════╝          └──→ GND Arduino
```

### 2. Branchement MPU6050

| Broche MPU6050 | → | Broche Arduino Mega |
|:---:|:---:|:---:|
| VCC | → | **3.3V** (ou 5V) |
| GND | → | **GND** |
| SDA | → | **Pin 20** (SDA) |
| SCL | → | **Pin 21** (SCL) |
| AD0 | → | GND (adresse I2C = 0x68) |
| INT | → | Non connecté |

### 3. Branchement des 12 servos

Chaque servo a **3 fils** :

| Couleur fil | Connexion |
|-------------|-----------|
| 🟤 Marron/Noir | GND (masse commune) |
| 🔴 Rouge | VCC **alimentation externe 6V** |
| 🟡 Jaune/Orange | Signal → pin Arduino ci-dessous |

| Servo | Patte | Articulation | Pin Arduino |
|:---:|:---:|:---:|:---:|
| 0 | **FR** (Avant Droite) | Abad (hanche latérale) | **D2** |
| 1 | **FR** | Upper (cuisse) | **D3** |
| 2 | **FR** | Lower (tibia) | **D4** |
| 3 | **FL** (Avant Gauche) | Abad | **D5** |
| 4 | **FL** | Upper | **D6** |
| 5 | **FL** | Lower | **D7** |
| 6 | **BR** (Arrière Droite) | Abad | **D8** |
| 7 | **BR** | Upper | **D9** |
| 8 | **BR** | Lower | **D10** |
| 9 | **BL** (Arrière Gauche) | Abad | **D11** |
| 10 | **BL** | Upper | **D12** |
| 11 | **BL** | Lower | **D13** |

### 4. Placement des caméras

```
Mode MONO (1 caméra)           Mode STÉRÉO (2 caméras)
                               
   [📷 cam]                     [📷 left]   [📷 right]
      │                            │              │
  /dev/video0                /dev/video0    /dev/video1
                               ←── ~8cm ───→
                               (baseline stéréo)
```

### ✅ Checklist avant mise sous tension

```
[ ] GND Arduino ────────── GND alimentation externe servos   ← OBLIGATOIRE
[ ] VCC servos ─────────── 6V alimentation externe           ← JAMAIS via Arduino
[ ] Condensateurs 1000µF── sur bornes alim externa           ← Anti-pic courant
[ ] SDA MPU6050 ─────────── Pin 20 Arduino                   ← I2C
[ ] SCL MPU6050 ─────────── Pin 21 Arduino                   ← I2C
[ ] USB Pi 5 ───────────── USB-B Arduino                     ← Serial + Flash
[ ] Caméra(s) USB ──────── Port(s) USB Pi 5                  ← Vision SLAM
[ ] Alim Pi USB-C ──────── 5V/5A officielle                  ← Pi 5 séparé
```

---

## Installation complète

### Étape 0 — Prérequis OS sur Raspberry Pi 5

Installer **Ubuntu Server 24.04 LTS ARM64** sur la carte SD via [Raspberry Pi Imager](https://www.raspberrypi.com/software/).

> **⚠️ Attention :** Utiliser Ubuntu 24.04 (Noble) ARM64 — **pas** Raspberry Pi OS. ROS 2 Jazzy requiert Ubuntu 24.04.

### Étape 1 — Cloner le repo

```bash
cd ~
git clone https://github.com/TON_USERNAME/spotbot-ros2.git
cd spotbot-ros2
```

### Étape 2 — Setup automatique complet (1 commande)

```bash
bash setup.sh
```

Cette commande fait **tout** dans l'ordre :
1. ✅ Installe ROS 2 Jazzy
2. ✅ Installe toutes les dépendances (rtabmap, nav2, usb_cam, avrdude...)
3. ✅ Build le workspace ROS 2 avec colcon
4. ✅ Installe arduino-cli, compile et flash le firmware sur l'Arduino Mega

> ⏱️ **Durée estimée sur Pi 5 :** 30 à 60 minutes (téléchargements inclus)

### Étape 3 (optionnelle) — Flash Arduino séparément

Si l'Arduino n'était pas branché lors du `setup.sh` :

```bash
# Brancher l'Arduino Mega en USB, puis :
bash install/install_arduino.sh
```

---

## Premier lancement

### 🚀 Lancement en 1 commande

```bash
# Source l'environnement (déjà ajouté au .bashrc automatiquement)
source ~/.bashrc

# Lancement global (mode mono par défaut)
ros2 launch spotbot_bringup spotbot.launch.py
```

**Ce qui se passe automatiquement :**
1. Le bridge détecte l'Arduino sur `/dev/ttyUSB0` ou `/dev/ttyACM0`
2. Le Motion Node démarre → envoie la pose **debout** à l'Arduino
3. L'Arduino reçoit les 12 angles et commande les servos → **le robot se lève**
4. La caméra USB démarre sur `/dev/video0`
5. rtabmap commence la cartographie
6. Le robot est prêt à recevoir des commandes

### Options de lancement

```bash
# 1 caméra USB (SLAM monoculaire)
ros2 launch spotbot_bringup spotbot.launch.py mode:=mono

# 2 caméras USB (SLAM stéréo — meilleure profondeur)
ros2 launch spotbot_bringup spotbot.launch.py mode:=stereo

# Avec visualisation RViz2 en temps réel
ros2 launch spotbot_bringup spotbot.launch.py mode:=mono rviz:=true

# Sans SLAM (déplacement seul, économise des ressources)
ros2 launch spotbot_bringup spotbot.launch.py slam:=false

# Mode localisation (carte déjà construite, navigation uniquement)
ros2 launch spotbot_slam rtabmap_mono.launch.py localization:=true
```

---

## Commandes utiles

### Contrôle du robot

```bash
# Contrôle clavier (z=avant, s=arrière, q/d=rotation)
ros2 run teleop_twist_keyboard teleop_twist_keyboard

# Position debout
ros2 topic pub --once /cmd_pose std_msgs/String "data: 'stand'"

# Position assise
ros2 topic pub --once /cmd_pose std_msgs/String "data: 'sit'"

# Changer de démarche : trot (rapide) | crawl (stable) | bound
ros2 topic pub --once /cmd_gait std_msgs/String "data: 'trot'"
ros2 topic pub --once /cmd_gait std_msgs/String "data: 'crawl'"
```

### Monitoring

```bash
# État de l'Arduino (connected/disconnected)
ros2 topic echo /arduino/status

# Données gyroscope + accéléromètre brutes
ros2 topic echo /imu/data_raw

# Image caméra (nécessite rqt)
ros2 run rqt_image_view rqt_image_view /camera/image_raw

# Carte en cours de construction
ros2 topic echo /rtabmap/info

# Voir le graphe de tous les noeuds actifs
ros2 run rqt_graph rqt_graph

# Statistiques ressources Pi
ros2 run rqt_top rqt_top
```

### Angles servo manuels (test)

```bash
# Envoyer des angles précis aux 12 servos (0-180°, 90°=neutre)
# Ordre: FR_abad, FR_upper, FR_lower, FL_abad, FL_upper, FL_lower,
#        BR_abad, BR_upper, BR_lower, BL_abad, BL_upper, BL_lower
ros2 topic pub --once /cmd_joint_angles std_msgs/Float32MultiArray \
  "data: [90.0, 90.0, 90.0, 90.0, 90.0, 90.0, 90.0, 90.0, 90.0, 90.0, 90.0, 90.0]"
```

### Gestion de la carte SLAM

```bash
# Sauvegarder la carte actuelle
ros2 service call /rtabmap/save_map std_srvs/srv/Empty

# Réinitialiser la carte (recommencer)
ros2 service call /rtabmap/reset std_srvs/srv/Empty
```

---

## Architecture du système

```
┌──────────────────────────────────────────────────────────────────┐
│                     RASPBERRY PI 5 — ROS 2 Jazzy                │
│                                                                  │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────────┐   │
│  │  usb_cam     │    │ imu_filter   │    │   rtabmap SLAM   │   │
│  │  Node        │    │ (Madgwick)   │    │   (mono/stéréo)  │   │
│  └──────┬───────┘    └──────┬───────┘    └────────┬────────-┘   │
│         │/camera/image_raw  │/imu/data            │/map         │
│         └───────────────────┴─────────────────────┘             │
│                                                                  │
│  ┌───────────────────┐    ┌──────────────────────┐              │
│  │  Motion Node      │    │  Arduino Bridge      │              │
│  │  (IK + Gait)      │───▶│  (Serial JSON)       │──▶ USB      │
│  └───────────────────┘    └──────────────────────┘              │
│         ▲/cmd_vel                ▲ /cmd_joint_angles             │
│         │                       │ /imu/data_raw ▼               │
│  [Téléop clavier]         [Arduino Mega 2560]                    │
└──────────────────────────────────────────────────────────────────┘
                                  │ USB Serial 115200 baud
                    ┌─────────────┴──────────────────┐
                    │         ARDUINO MEGA 2560       │
                    │                                 │
                    │  ┌──────────┐  ┌─────────────┐ │
                    │  │ 12 PWM   │  │  MPU6050    │ │
                    │  │ Servos   │  │  I2C Read   │ │
                    │  │ MG996R   │  │  (50 Hz)    │ │
                    │  └──────────┘  └─────────────┘ │
                    └─────────────────────────────────┘
```

### Packages ROS 2

| Package | Rôle | Fichiers clés |
|---------|------|---------------|
| `spotbot_bringup` | Orchestration | `spotbot.launch.py` |
| `spotbot_description` | Modèle 3D (URDF) | `spotbot.urdf.xacro` |
| `spotbot_slam` | Cartographie V-SLAM | `rtabmap_mono/stereo.launch.py` |
| `spotbot_motion` | Cinématique + démarche | `motion_node.py`, `ik_solver.py`, `gait_controller.py` |
| `spotbot_arduino_bridge` | Comm Arduino | `arduino_bridge_node.py` |

---

## Modes de fonctionnement

### Mode SLAM Monoculaire (`mode:=mono`)

- **1 caméra USB** sur `/dev/video0`
- rtabmap estime la profondeur depuis le mouvement (odométrie visuelle)
- Précision correcte pour environnements intérieurs
- **Recommandé pour démarrer**
- Consommation CPU : ~60% sur Pi 5

### Mode SLAM Stéréo (`mode:=stereo`)

- **2 caméras USB** : gauche `/dev/video0`, droite `/dev/video1`
- La profondeur est calculée par disparité → bien meilleure précision
- Nécessite une calibration stéréo (voir section calibration)
- Baseline caméras : 6–12 cm
- Consommation CPU : ~80% sur Pi 5

### Mode Navigation (`localization:=true`)

- Une carte a déjà été construite et sauvegardée
- rtabmap se localise sur cette carte existante (re-localisation)
- On peut combiner avec Nav2 pour navigation autonome vers des waypoints

---

## Calibration des servos

Les servos peuvent avoir des positions mécaniques différentes selon le montage.  
Éditez les valeurs dans `arduino/spotbot_controller/spotbot_controller.ino` :

```cpp
// Angles en degrés — 90 = neutre (centré)
// Ajustez jusqu'à ce que chaque articulation soit à la bonne position mécanique

const float SERVO_STAND[NUM_SERVOS] = {
    90, 90, 90,   // FR : abad (hanche), upper (cuisse), lower (tibia)
    90, 90, 90,   // FL : ...
    90, 90, 90,   // BR : ...
    90, 90, 90    // BL : ...
};
```

**Procédure de calibration pas à pas :**

```bash
# 1. Lancer uniquement le bridge Arduino (sans motion)
ros2 launch spotbot_arduino_bridge arduino_bridge.launch.py

# 2. Tester servo par servo (premier servo = FR Abad)
ros2 topic pub --once /cmd_joint_angles std_msgs/Float32MultiArray \
  "data: [90.0, 90.0, 90.0, 90.0, 90.0, 90.0, 90.0, 90.0, 90.0, 90.0, 90.0, 90.0]"

# 3. Ajuster la valeur du servo concerné (ex: servo 0 à 95°)
ros2 topic pub --once /cmd_joint_angles std_msgs/Float32MultiArray \
  "data: [95.0, 90.0, 90.0, 90.0, 90.0, 90.0, 90.0, 90.0, 90.0, 90.0, 90.0, 90.0]"

# 4. Répéter pour chaque servo jusqu'à position debout correcte

# 5. Reporter les valeurs dans spotbot_controller.ino
# 6. Reflasher: bash install/install_arduino.sh
```

---

## Dépannage

### ❌ "Arduino non trouvé"

```bash
# Vérifier que le câble USB est bien branché et que l'Arduino est allumé
ls -la /dev/ttyUSB* /dev/ttyACM*

# Si pas de device, vérifier le câble et les drivers
lsusb | grep -i arduino

# Vérifier les droits d'accès
sudo usermod -aG dialout $USER
# Puis redémarrer la session
```

### ❌ "Permission denied sur /dev/ttyUSB0"

```bash
sudo chmod 666 /dev/ttyUSB0
# ou de façon permanente:
sudo usermod -aG dialout $USER
```

### ❌ "Caméra non trouvée"

```bash
# Lister les caméras disponibles
ls /dev/video*
v4l2-ctl --list-devices

# Tester la caméra
ros2 run usb_cam usb_cam_node_exe --ros-args \
  -p video_device:=/dev/video0 \
  -p framerate:=30.0
```

### ❌ rtabmap lag ou lent

```bash
# Réduire la résolution dans le launch camera_mono.launch.py
# Changer width:=640 height:=480  →  width:=320 height:=240

# Ou réduire le framerate de 30 à 15 FPS
```

### ❌ Les servos vibrent ou ne bougent pas

1. Vérifier que l'alimentation externe **6V/10A** est allumée
2. Vérifier que le GND de l'alim externe est connecté au GND Arduino
3. Vérifier les angles dans `SERVO_STAND` : valeurs entre 0 et 180 uniquement
4. Reflasher l'Arduino : `bash install/install_arduino.sh`

### ❌ Build colcon échoué

```bash
# Nettoyer et rebuilder
cd ~/spotbot-ros2/ros2_ws
rm -rf build/ install/ log/
colcon build --symlink-install --cmake-args -DCMAKE_BUILD_TYPE=Release
```

---

## Répertoire des fichiers

```
spotbot-ros2/
│
├── 📄 README.md                    ← Ce fichier
├── 📄 HARDWARE_SETUP.md            ← Guide branchements détaillé
├── 🔧 setup.sh                     ← Setup complet en 1 commande
│
├── 📁 install/
│   ├── install_ros2.sh             ← ROS 2 Jazzy
│   ├── install_deps.sh             ← Dépendances ROS (rtabmap, nav2...)
│   ├── install_arduino.sh          ← arduino-cli + compile + flash
│   └── build_workspace.sh          ← colcon build
│
├── 📁 arduino/
│   └── spotbot_controller/
│       └── spotbot_controller.ino  ← Firmware Arduino (servos + IMU)
│
└── 📁 ros2_ws/src/
    │
    ├── spotbot_bringup/
    │   └── launch/
    │       ├── spotbot.launch.py       ← POINT D'ENTRÉE PRINCIPAL
    │       ├── camera_mono.launch.py   ← Caméra mono USB
    │       └── camera_stereo.launch.py ← 2 caméras USB
    │
    ├── spotbot_description/
    │   └── urdf/spotbot.urdf.xacro    ← Modèle 3D 12-DOF
    │
    ├── spotbot_slam/
    │   ├── launch/
    │   │   ├── rtabmap_mono.launch.py    ← SLAM monoculaire
    │   │   └── rtabmap_stereo.launch.py  ← SLAM stéréo
    │   └── params/
    │       ├── rtabmap_mono.yaml    ← Paramètres tunés Pi 5
    │       └── rtabmap_stereo.yaml
    │
    ├── spotbot_motion/
    │   └── spotbot_motion/
    │       ├── ik_solver.py         ← Cinématique inverse analytique
    │       ├── gait_controller.py   ← Courbes de Bézier (trot/crawl)
    │       └── motion_node.py       ← Nœud ROS 2 mouvement
    │
    └── spotbot_arduino_bridge/
        └── spotbot_arduino_bridge/
            ├── arduino_bridge_node.py  ← Bridge Pi↔Arduino (auto-détect)
            └── arduino_flasher.py      ← Utilitaire flash standalone
```

---

## Résumé : Du git clone au robot debout

```bash
# Sur le Raspberry Pi 5 (Ubuntu 24.04, tout branché)

git clone https://github.com/TON_USERNAME/spotbot-ros2.git
cd spotbot-ros2
bash setup.sh

# Attendre 30-60 min...

source ~/.bashrc
ros2 launch spotbot_bringup spotbot.launch.py
# → Le robot se lève 🐾
```

---

<div align="center">

**SpotBot — Fait avec ❤️ et ROS 2**

*Pour toute question : ouvrir une Issue sur le repo GitHub*

</div>
